# materialize-select2
Simple jquery plugin that implements select2 in materializecss framework.
## [Example] (https://jsfiddle.net/nikitasnv/6v12po6z/)